var searchData=
[
  ['topixels',['toPixels',['../classcom_1_1billdawson_1_1timodules_1_1animation_1_1_android_animation.html#ae8bd71b87f4f3f2be9d3b8a75e330e57',1,'com::billdawson::timodules::animation::AndroidAnimation']]],
  ['translationx',['translationX',['../classcom_1_1billdawson_1_1timodules_1_1animation_1_1views_1_1_view_property_animator__.html#a079507191b7344c3cb90d04f645b52af',1,'com::billdawson::timodules::animation::views::ViewPropertyAnimator_']]],
  ['translationxby',['translationXBy',['../classcom_1_1billdawson_1_1timodules_1_1animation_1_1views_1_1_view_property_animator__.html#a07fd7d2a988f176f39df2ec4b0a49790',1,'com::billdawson::timodules::animation::views::ViewPropertyAnimator_']]],
  ['translationy',['translationY',['../classcom_1_1billdawson_1_1timodules_1_1animation_1_1views_1_1_view_property_animator__.html#a85b6837296ace23c94cad80efd75c96f',1,'com::billdawson::timodules::animation::views::ViewPropertyAnimator_']]],
  ['translationyby',['translationYBy',['../classcom_1_1billdawson_1_1timodules_1_1animation_1_1views_1_1_view_property_animator__.html#a14d175aee59dca4b67cb10a6c29aa12f',1,'com::billdawson::timodules::animation::views::ViewPropertyAnimator_']]]
];
